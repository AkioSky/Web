<?php defined('_JEXEC') or die;?>
<script type="text/javascript">
	function onChangePerPage() {
		var selector = document.getElementById("selectionPerPage");
		var perPage = selector.options[selector.selectedIndex].value;
		if (perPage == "")
			return false;
		var postString =  "<?php echo JRoute::_('index.php?option=com_property&view=property&page=1&perpage=&'.$this->postString);?>";
		var locationStr = postString.replace("perpage=&", "perpage=" + perPage +"&");
		var locationStr = locationStr.replace(/&amp;/g, '&');
		window.location = locationStr;
	}
</script>
<style>
.thumbnails-photo img {
	height:auto; 
	width:350px; 
	border: 5px solid #f2682a;
	border-top-left-radius: 5px;
	border-top-right-radius: 5px;
}
.full-details-button-thumbs {
	background-color: #f2682a;
	padding-top: 10px;
	padding-right: 15px;
	padding-bottom: 10px;
	padding-left: 15px;
	border-bottom-left-radius: 5px;
	border-bottom-right-radius: 5px;
	clear: both;
	width:330px;
	text-align: center;
	margin-bottom: 10px
}
.full-details-button-thumbs a {color: white;}
div.plain-link {
	color: #f2682a;
	font-size: 1.5em;
}
.thumbnails-container{
	margin: 20px;
	border-bottom: 4px dashed #f2682a;
}
#googlemap img{max-width:none;}
#selectionPerPage{margin-bottom:0px; width: auto; height: 25px; font-size: 12px;}
</style>
<?php 
	if($this->formData['rentalPeriod']==0)
		$ptype="propertySearchSales";
	else
		$ptype="propertySearchLettings";
	$pages = $this->searchResult->xpath('/response/'.$ptype.'/properties/pages/page');
	$page_info = $this->searchResult->xpath('/response/'.$ptype.'/properties/pages');
?>

<div class="pagination_cointainer">
<ul class="pagination">
	<li class="pages"><a href="<?php echo JRoute::_('index.php?option=com_property&view=property&page=1&perpage='.(int)$page_info[0]['perPage'].'&'.$this->postString);?>">First</a></li>
	<?php foreach($pages  as $page){
		$page_attributes = $page->attributes();
		if ( $page_attributes->selected == "true" ) 
			echo "<li class='pages' style='background-color: #DDD;'><a class='pagecontrollink'>".$page_attributes->number."</a></li>";
		else{
	?>
	<li class="pages"><a class="pagecontrollink" href="<?php echo JRoute::_('index.php?option=com_property&view=property&page='.$page_attributes->number.'&perpage='.(int)$page_info[0]['perPage'].'&'.$this->postString);?>"><?php echo $page_attributes->number;?></a></li>
		<?php } ?>
	<?php } ?>
	<li class="next"><a href="<?php echo JRoute::_('index.php?option=com_property&view=property&page='.(int)$page_info[0]['pageCount'].'&perpage='.(int)$page_info[0]['perPage'].'&'.$this->postString);?>">Last</a></li>
	<li class="perPage">
		<select onchange="onChangePerPage()" id="selectionPerPage">
			<option value="">-Per Page-</option>
			<option value="5">5</option>
			<option value="10">10</option>
			<option value="25">25</option>
			<option value="50">50</option>
			<option value="100">100</option>
		</select>
	</li>
</ul>

</div>
<?php
	if ($this->displayType == 'false')
		echo $this->loadTemplate('results');
	else
		echo $this->loadTemplate('results_map');