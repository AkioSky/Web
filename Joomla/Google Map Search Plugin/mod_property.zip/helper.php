<?php
class modPropertyHelper
{
}