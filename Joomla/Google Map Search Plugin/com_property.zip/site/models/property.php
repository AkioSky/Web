<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla modelitem library
jimport('joomla.application.component.modelitem');
class PropertyModelProperty extends JModelItem
{
	public $page;
	public $perpage;
	public $postString;
	
	function __construct() {
		parent::__construct();
		$app = JFactory::getApplication('site');
		$this->page = $app->input->get('page');
		$this->perpage = $app->input->get('perpage');
	}	
	function getData(){
		define('POSTURL', 'http://www.dezrez.com/DRApp/DotNetSites/WebEngine/property/Default.aspx');
		$post_string = $this->getPostString();
		$ch = curl_init(POSTURL);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_HEADER, 0);  // DO NOT RETURN HTTP HEADERS
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  // RETURN THE CONTENTS OF THE CALL
		$Rec_Data = curl_exec($ch);
		curl_close($ch);
		$xml = new SimpleXMLElement($Rec_Data);
		return $xml;
	}
	
	public function getDisplayType() {
		return $_GET['mapView'];
	}
	
	public function getFormData() {
		return $_GET;
	}
	public function getPostString() {
		$post_data = $_GET;
		$post_items = array();
		$post_items['apikey'] = 'EDC1196E-D727-4AAC-967C-A47A78C0929A';
		$post_items['eaid'] = 371;
		$post_items['xslt'] = -1;
		$post_items['minPrice'] = $post_data['minPrice'];
		$post_items['maxPrice'] = $post_data['maxPrice'];
		$post_items['bedrooms'] = $post_data['bedrooms'];
		$post_items['showSTC'] = true;
		$post_items['searchAllAddress'] = $post_data['searchAllAddress'];
		$post_items['rentalPeriod'] = $post_data['rentalPeriod'];
		$post_items['sortDescending'] = true;
		$post_items['page'] = $this->page;
		$post_items['perpage'] = $this->perpage;
		$post_string = "";
		foreach( $post_items as $key => $value ) {
			$post_string .= '&'.$key.'='.$value;
		}
		$this->postString = $post_string;
		return $this->postString;
	}
}