<?php defined('_JEXEC') or die;?>
<style>
#PropertySearchForm table{width: 93%; text-align: center; color:black;}
#PropertySearchForm table select{width: 80%;}
#PropertySearchForm table td{width: 50%;}
#PropertySearchForm table td label{color: white;}
#PropertySearchForm table #searchAllAddress{width: 72%; margin-top: 0px;}
#PropertySearchForm input[type="button"]{width: 80%; margin-right:0px; font-size: 18px;}
</style>
<script language="javascript" type="text/javascript">
	window.onload = rentalPeriodCheck;
	function rentalPeriodCheck() {
		var minPrice = document.getElementById("minPrice");
		var maxPrice = document.getElementById("maxPrice");
		var letOrsale = document.getElementById("rentalPeriod");
		var buyStr =  "<option value='50000'>&pound;50,000</option>"
		        	+ "<option value='100000'>&pound;100,000</option>"
		        	+ "<option value='150000'>&pound;150,000</option>"
		        	+ "<option value='200000'>&pound;200,000</option>"
		        	+ "<option value='250000'>&pound;250,000</option>"
		        	+ "<option value='300000'>&pound;300,000</option>"
		        	+ "<option value='350000'>&pound;350,000</option>"
		        	+ "<option value='400000'>&pound;400,000</option>"
		        	+ "<option value='500000'>&pound;500,000</option>"
		        	+ "<option value='750000'>&pound;750,000</option>";
		var letStr =  "<option value='400'>&pound;400</option>"
		        	+ "<option value='425'>&pound;425</option>"
		        	+ "<option value='450'>&pound;450</option>"
		        	+ "<option value='475'>&pound;475</option>"
		        	+ "<option value='500'>&pound;500</option>"
		        	+ "<option value='550'>&pound;550</option>"
		        	+ "<option value='600'>&pound;600</option>"
		        	+ "<option value='650'>&pound;650</option>"
		        	+ "<option value='700'>&pound;700</option>"
		        	+ "<option value='750'>&pound;750</option>"
		        	+ "<option value='800'>&pound;800</option>"
		        	+ "<option value='850'>&pound;850</option>";
		if ( letOrsale.options[letOrsale.selectedIndex].value == "4" ) {
			minPrice.innerHTML = "<option value='0'>Minimum Price</option>"
					+ letStr
		        	+ "<option value='900'>&pound;900</option>";
		    
			maxPrice.innerHTML = "<option value='9999'>Maximum Price</option>"
					+ letStr
		        	+ "<option value='9999'>&pound;900+</option>";
		}else {
			minPrice.innerHTML = "<option value='0'>Minimum Price</option>"
					+ buyStr
		        	+ "<option value='1000000'>&pound;1,000,000</option>";
		    
			maxPrice.innerHTML = "<option value='99999999'>Maximum Price</option>"
					+ buyStr
		        	+ "<option value='99999999'>&pound;1,000,000+</option>";
		}
	}
	function processForm() {
		document.getElementById("mapView").value = document.getElementById("mapSearch").checked;
		document.getElementById("PropertySearchForm").submit();
	}
</script>

<form id="PropertySearchForm" name="PropertySearchForm" method=GET action="<?php echo JRoute::_('index.php?option=com_property&view=property', false); ?>">
	<input type="hidden" id="page" name="page" value="1" />
	<input type="hidden" id="perpage" name="perpage" value="5" />
	<input type="hidden" id="mapView" name="mapView" value="false" />
    <table>
	    <tr>
	    	<td><label for="rentalPeriod" style="text-align: center;">Select Mode >>></label></td>
	    	<td><select name="rentalPeriod" id="rentalPeriod" onchange="javascript:rentalPeriodCheck();">
                <option value="4">To-Let</option>
                <option value="0">For-Sale</option>
            </select></td>
	    </tr>
		<tr>
			<td><select name="minPrice" id="minPrice"></select></td>
			<td><select name="maxPrice" id="maxPrice"></select></td>
		</tr>
		<tr>
			<td><select name="bedrooms" id="bedrooms">
                <option value="">Beds(No Specified)</option>
                <option value="1">1 or more</option>
                <option value="2">2 or more</option>
                <option value="3">3 or more</option>
                <option value="4">4 or more</option>
                <option value="5">5 or more</option>
            </select></td>
			<td><input type="text" id="searchAllAddress" name="searchAllAddress" placeholder="Location..."/></td>
		</tr>
		<tr>
			<td><input type="checkbox" id="mapSearch" style="margin-top: 0px; margin-right: 10px;" unchecked><label for="mapSearch" style="display: inline-block;">Map Results</label></td>
			<td><input type="button" value="Search" onclick="javascript:processForm();" /></td>
		</tr>
    </table>
</form>