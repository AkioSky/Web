<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla view library
jimport('joomla.application.component.view');
 
class PropertyViewPropertyDetail extends JViewLegacy
{
	public $propertyDetailResult;
	
	function display($tpl = null) 
	{
		if (count($errors = $this->get('Errors'))) 
		{
			JLog::add(implode('<br/>', $errors), JLog::WARNING, 'jerror');
			return false;
		}
		$this->propertyDetailResult = $this->get("PropertyDetail");
		parent::display($tpl);
	}
}