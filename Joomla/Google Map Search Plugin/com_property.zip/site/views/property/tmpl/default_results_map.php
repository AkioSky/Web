<?php defined('_JEXEC') or die; ?>
<?php
if ( $this->formData['rentalPeriod'] == 0 ) {
	$ptype = "propertySearchSales";
	$sale = "For Sale"; 
}
else {
	$ptype = "propertySearchLettings";
	$sale = "To Let";
}
$results = $this->searchResult->xpath('/response/'.$ptype.'/properties/property');
$i = 0;
$beaches = 'var beaches = [';
$infoDatas = "var infoDatas = [";
$cnt = count($results);
?>
<div class="search-results row-fluid">
	<div class="span4">
		<?php foreach($results as $result) : ?>
			<?php
				$i++;
				$attributes = $result->attributes();
				if ( $i == 1 ){
					$longitude = $attributes->longitude;
					$latitude = $attributes->latitude;
				}
				$beaches .= "['".$result->useAddress."', ".$attributes->latitude.", ".$attributes->longitude.", ".$i."]";
				if ( $i < $cnt )
					$beaches.=',';
				if ( $attributes->picture == "true" )
					$photoid = 1;
				else 
					$photoid = 0;

				if ( $attributes->POA == "true" )
					$poa = "POA";
				else 
					$poa = $attributes->price;
				
				switch($attributes->rescomnew){
				   case 1:$pcat="Residential";
				   break;
				   case 2:$pcat="New build";
				   break;
				   case 3:$pcat="Commercial";
				   break;
				   case 4:$pcat="Land";
				   break;
				   case 5:$pcat="Foreign";
				   break;
				   case 6:$pcat="Other";
				   break;
				   case 7:$pcat="Investment";
				   break;
				   case 8:$pcat="Mooring";
				   break; 
				   default:break;
				}
				if ( $attributes->rentalperiod ){
				    switch ( $attributes->rentalperiod ){
						case 0:
						case 1:
							$rp="sale property";
							break;
						case 2:
							$rp="per day";
							break;
						case 3:
							$rp="per week";
							break;
						case 4:
							$rp="per month";
							break;
						case 5:
							$rp="per quarter";
							break;
						case 6:
							$rp="per year";
							break;
						default:
							$rp="";
							break;
				    }
				}
		?>
		<div class = "black_box">
			<a href="<?php echo JRoute::_('index.php?option=com_property&view=propertydetail&pid='.$attributes->id);?>">
				<img border="0" alt="Click the photo for more details for this property " src="http://www.dezrez.com/DRApp/DotNetSites/WebEngine/property/pictureResizer.aspx?eaid=<?php echo $attributes->eaid;?>&apikey=EDC1196E-D727-4AAC-967C-A47A78C0929A&pid=<?php echo $attributes->id;?>&bid=<?php echo $attributes->bid;?>&picture=<?php echo $photoid;?>&width=100" style="max-width:none; height:62px; width:85px; border:inset; border-width:1px; border-color:#FFF">
			</a>
		  	<div><a class="plain-link" href="<?php echo JRoute::_('index.php?option=com_property&view=propertydetail&pid='.$attributes->id);?>"><strong><?php echo $sale;?> | <?php echo $poa;?> </strong></a></div>
		  	<a class="plain-link" href="<?php echo JRoute::_('index.php?option=com_property&view=propertydetail&pid='.$attributes->id);?>"><?php echo $result->useAddress.", ". $result->postcode;?></strong></a>
		</div>
		<?php 
			$infoDatas .= "'<div class=infoWindow><a href=".JRoute::_('index.php?option=com_property&view=propertydetail&pid='.$attributes->id).">";
			$infoDatas .= "<div><img src=http://www.dezrez.com/DRApp/DotNetSites/WebEngine/property/pictureResizer.aspx?eaid=".$attributes->eaid."&apikey=EDC1196E-D727-4AAC-967C-A47A78C0929A&pid=".$attributes->id."&bid=".$attributes->bid."&picture=".$photoid."&width=200></div>";
			$infoDatas .= "<div><strong>".$sale." | ".$poa."</strong></div>";
			$infoDatas .= "<div>".$result->useAddress."</div>";
			$infoDatas .= "</a></div>'";
			if ( $i < $cnt )
				$infoDatas.=',';
		?>
		<?php endforeach; ?>
		<?php
		    $beaches .= '];';
		    $infoDatas .= "];";
		?>
	</div>
	<div class="span8" style="border:2px solid #333333; border-radius:2px;">
		<div id="googlemap" style="width:100%; height: 810px;"></div>
	</div>
</div>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
<script type="text/javascript">
	<?php 
		echo $beaches;
		echo $infoDatas;
	?>
	window.onload = initialize;
	function initialize() {
  		var myOptions = {
	    	zoom: 10,
	   		center: new google.maps.LatLng(<?php echo $latitude;?>,<?php echo $longitude;?>),
	    	mapTypeId: google.maps.MapTypeId.ROADMAP
  		}
  		var map = new google.maps.Map(document.getElementById("googlemap"),myOptions); 
  		setMarkers(map, beaches);
	}

	var infowindow =  new google.maps.InfoWindow({
        content: "",
        maxWidth: 250
    });
	function setMarkers(map, locations) {
	  	var image = new google.maps.MarkerImage('/mapicon.png',
	      	new google.maps.Size(20, 32),
	      	new google.maps.Point(0,0),
	      	new google.maps.Point(0, 32));

	  	for (var i = 0; i < locations.length; i++) {
	    	var beach = locations[i];
	    	var myLatLng = new google.maps.LatLng(beach[1], beach[2]);
	    	var marker = new google.maps.Marker({
	        	position: myLatLng,
	        	map: map,
	        	icon: image,
	        	title: beach[0],
				zIndex: beach[3]
	    	});
			bindInfoWindow(marker, map, infowindow, infoDatas[i]);
	  	}
	}
	
	function bindInfoWindow(marker, map, infowindow, strDescription) {
	    google.maps.event.addListener(marker, 'click', function() {
	        infowindow.setContent(strDescription);
	        infowindow.open(map, marker);
	    });
	}
</script>