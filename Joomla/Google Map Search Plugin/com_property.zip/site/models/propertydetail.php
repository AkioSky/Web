<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla modelitem library
jimport('joomla.application.component.modelitem');
class PropertyModelPropertyDetail extends JModelItem
{
	function getPID() {
		$app = JFactory::getApplication('site');
		return $app->input->get('pid');
	}
	
	function getPropertyDetail() {
		$pid = $this->getPID();
		$post_string = "&pid=".$pid;
		$post_string .= "&sessionGUID=".$this->getGUID();
		define('POSTURL', 'http://www.dezrez.com/DRApp/DotNetSites/WebEngine/property/Property.aspx?eaid=371&apiKey=EDC1196E-D727-4AAC-967C-A47A78C0929A&xslt=-1'.$post_string);
		
		$ch = curl_init(POSTURL);
		curl_setopt($ch, CURLOPT_POST      ,1);
		curl_setopt($ch, CURLOPT_POSTFIELDS    ,$post_string);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION  ,1);
		curl_setopt($ch, CURLOPT_HEADER      ,0);  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER  ,1);  
		$Rec_Data = curl_exec($ch);
		curl_close($ch);

		$xml = new SimpleXMLElement($Rec_Data);
		return $xml;
	}
	
	function getGUID()
	{
		$theGuid = uniqid(uniqid(), true);
		return $theGuid;
	}
}