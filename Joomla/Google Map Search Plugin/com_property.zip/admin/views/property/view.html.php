<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
jimport('joomla.application.component.view');

class PropertyViewProperty extends JViewLegacy
{
	function display($tpl = null) 
	{
		$this->addToolBar();
		parent::display($tpl);
	}

	protected function addToolBar()
	{
		JToolBarHelper::title(JText::_('Property Component'));
	}
}