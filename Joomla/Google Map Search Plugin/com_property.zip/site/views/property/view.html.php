<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
// import Joomla view library
jimport('joomla.application.component.view');
 
class PropertyViewProperty extends JViewLegacy
{
	public $searchResult;
	public $displayType;
	public $formData;
	public $postString;

	function display($tpl = null) 
	{
		if (count($errors = $this->get('Errors'))) 
		{
			JLog::add(implode('<br/>', $errors), JLog::WARNING, 'jerror');
			return false;
		}
		$this->searchResult = $this->get('Data');
		$this->displayType = $this->get('DisplayType');
		$this->formData = $this->get('FormData');
		$this->getPostString();
		parent::display($tpl);
	}
	
	function getPostString() {
		foreach ( $this->formData as $key => $value) {
			if ($key == "page" || $key == "perpage" )
				continue;
    		$post_items[] = $key . '=' . $value;
		}
		$this->postString = implode ('&', $post_items);
	}
}