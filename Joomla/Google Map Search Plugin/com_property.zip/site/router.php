<?php
defined('_JEXEC') or die;

 
class PropertyRouter extends JComponentRouterBase
{
	public function build(&$query)
	{
		$segments = array();
       	if (isset($query['view'])){
	    	$segments[] = $query['view'];
	        unset($query['view']);
	    }
       	if (isset($query['pid'])){
        	$segments[] = $query['pid'];
            unset($query['pid']);
		};
		return $segments;
	}

	public function parse(&$segments)
	{
		$vars = array();
       	switch($segments[0])
       	{
		case 'property':
			$vars['view'] = 'property';
		    break;
		case 'propertydetail':
		    $vars['view'] = 'propertydetail';
		    $vars['pid'] = $segments[1];
		    break;
		}
       	return $vars;
	}
}

function PropertyBuildRoute(&$query)
{
	$router = new PropertyRouter;

//	return $router->build($query);
}

function PropertyParseRoute($segments)
{
	$router = new PropertyRouter;

//	return $router->parse($segments);
}
