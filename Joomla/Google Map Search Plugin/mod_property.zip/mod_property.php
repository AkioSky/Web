<?php
defined('_JEXEC') or die;

require_once( dirname(__FILE__) . '/helper.php' );
require( JModuleHelper::getLayoutPath('mod_property'));