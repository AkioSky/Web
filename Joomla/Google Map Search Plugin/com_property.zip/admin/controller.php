<?php
// No direct access to this file
defined('_JEXEC') or die;
 
class PropertyController extends JControllerLegacy
{
	function display($cachable = false, $urlparams = false) 
	{
		$input = JFactory::getApplication()->input;
		$input->set('view', $input->getCmd('view', 'Property'));
		
		parent::display($cachable);
	}
}