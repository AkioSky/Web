<?php defined('_JEXEC') or die; ?>

<dl class="search-results">
<?php 
if($this->formData['rentalPeriod']==0){
	$ptype="propertySearchSales";
	$sale="For Sale";
}
else{ 
	$ptype="propertySearchLettings";
	$sale="To Let";
}
$results = $this->searchResult->xpath('/response/'.$ptype.'/properties/property');
?>
<?php foreach($results as $result) : ?>
<?php
$attributes = $result->attributes();

if ( $attributes->picture == "true" )
	$photoid=1;
else 
	$photoid=0;

if ( $attributes->POA == "true" )
	$poa="POA";
else 
	$poa=$attributes->price;

switch($attributes->rescomnew){
   	case 1:
   		$pcat="Residential";
   		break;
	case 2:
		$pcat="New build";
		break;
	case 3:
		$pcat="Commercial";
		break;
	case 4:
		$pcat="Land";
		break;
	case 5:
		$pcat="Foreign";
		break;
	case 6:
		$pcat="Other";
		break;
	case 7:
		$pcat="Investment";
		break;
	case 8:
		$pcat="Mooring";
		break; 
	default:
		break;
}

if($attributes->rentalperiod){
    switch($attributes->rentalperiod){
       case 0:
       case 1:
	       $rp="sale property";
	       break;
       case 2:
	       $rp="per day";
	       break;
       case 3:
	       $rp="per week";
	       break;
       case 4:
	       $rp="per month";
	       break;
       case 5:
	       $rp="per quarter";
	       break;
       case 6:
	       $rp="per year";
	       break;
       default:
	       $rp="";
	       break;
    }
}
?>

<div class="thumbnails-container">
	<div class="thumbnails-photo">
		<a href="<?php echo JRoute::_('index.php?option=com_property&view=propertydetail&pid='.$attributes->id);?>">
			<img border="0" alt="Click the photo for more details of this property, " src="http://www.dezrez.com/DRApp/DotNetSites/WebEngine/property/pictureResizer.aspx?eaid=<?php echo $attributes->eaid;?>&apikey=EDC1196E-D727-4AAC-967C-A47A78C0929A&pid=<?php echo $attributes->id;?>&bid=<?php echo $attributes->bid;?>&picture=<?php echo $photoid;?>&width=980">
		</a>
		<div class="full-details-button-thumbs"><a href="<?php echo JRoute::_('index.php?option=com_property&view=propertydetail&pid='.$attributes->id);?>">More Detail >>></a></div>
	</div>
	
	<div class="thumbnails-detail">
		<div class="thumbnails-header">
			<div style="float:left"><div class="plain-link"><?php echo $sale;?> | <?php echo $poa;?></div></div>
			<div class="thumbnails-beds"><?php  if($attributes->bedrooms > 0) echo "<BR>".$attributes->bedrooms." bedrooms "; echo "<br>".$pcat;?></div>
	  	</div>
	  	<div class="thumbnails-description">
		  	<p align="left"><a class="plain-link" href="<?php echo JRoute::_('index.php?option=com_property&view=propertydetail&pid='.$attributes->id);?>"><strong><?php echo $result->useAddress.", ". $result->postcode;?></strong></a></p>
		    <p><?php echo $result->summaryDescription;?></p>

			<div style="clear:both"></div>
		    <p> Telephone : <?php echo $attributes->EATel;?></p>
	  	</div>
	</div>
	<div style="clear: both"></div>
</div>
<?php endforeach; ?>
<br>
</dl>