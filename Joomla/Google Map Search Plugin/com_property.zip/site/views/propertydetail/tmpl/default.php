<?php defined('_JEXEC') or die;?>
<style>
	div.property_main_img img {
		border: 5px solid #f2682a;
		border-radius: 5px;
	}
	#main_image {
		max-width: none;
	}
	#imagechanger {
		border: 3px solid #f2682a;
		border-radius: 3px;
		max-width: none;
		margin-bottom: 3px;
	}
	td.titleTd {
		font-size:1em;
		color: #f2682a;
		padding-right: 20px;
	}
	td.pricetd {
		font-size:1.2em;
		color: #f2682a;
	}
	td.addresstd {
		color: #f2682a;
	}
	div.Description1 {
		padding-left: 20px;
		color: grey;
	}
	#content_results{
		margin: 20px;
	}
</style>

<?php
	$property = $this->propertyDetailResult->xpath('/response/propertyFullDetails/property');
	$pictures = $this->propertyDetailResult->xpath('/response/propertyFullDetails/property/media');
	$branch = $this->propertyDetailResult->xpath('/response/propertyFullDetails/property/branch');
	$features = $this->propertyDetailResult->xpath('/response/propertyFullDetails/property/text/areas/area/feature');
	$address = $this->propertyDetailResult->xpath('/response/propertyFullDetails/property/address');
	$desc = $this->propertyDetailResult->xpath('/response/propertyFullDetails/property/text');
	
	$pattributes=$property[0]->attributes();
	if( $pattributes->sale == "true")
		$sale = "Asking Price ";
	else 
		$sale = "Rent per month ";
?>
<div id="content_results">

<table width="540" cellspacing="0" cellpadding="0" border="0" class="property">
<tbody>
<tr>
	<td class="overline">
		<table width="100%" cellspacing="3" cellpadding="0" border="0">
			<tbody><tr>
				<td id="pictd" rowspan="2" valign="top">
				    <div showifcontains="IMG" class="property_main_img"><img src="<?php echo $pictures[0]->picture[0];?>&width=980" width="780" id="main_image"/></div>
				</td>
				<td valign="top">
				    <?php foreach($pictures[0]->picture as $picture){?>
						<img border="0" title="" alt="" class="imagechangermain" id="imagechanger" src="<?php echo $picture;?>&width=980" width="80" onmouseover="document.getElementById('main_image').src=this.src" >
					<?php } ?>
				</td>
				<td width="60" valign="top" rowspan="2">
				</td>
			</tr>
		</tbody></table>
	</td>
</tr>
<tr>
	<td class="addresstd">
		<address style="TEXT-ALIGN:Left;"><?php echo $address[0]->useAddress; ?> , <?php echo $address[0]->postcode; ?></address>
	</td>
</tr>
<tr>
	<td id="price" class="pricetd">
		<span class="Price"><strong><?php echo $sale;?></strong><?php echo $pattributes->price;?></span>&nbsp;<span class="RentalPeriod"></span>  
	</td>
</tr>					
<tr>
	<td class="underline">
		<table cellspacing="0" cellpadding="0" border="0" class="info">
			<tbody>
			<p> <p>
			<tr>
				<td valign="top" class="titleTd"><b>No of page hits for this property  </b>
				</td>
				<td><?php echo $pattributes->hits;?>
				</td>
			</tr>
			<tr>
				<td valign="top" class="titleTd"><b>No of Bedrooms  </b>
				</td>
				<td><?php echo $pattributes->bedrooms;?>
				</td>
			</tr>
			<tr>
				<td class="titleTd"><b>Parking Spaces </b>
				</td>
				<td><?php echo $pattributes->parkingSpaces;?>
				</td>
			</tr>
			<tr>
				<td valign="top" class="titleTd"><b>Features </b>
				</td>
				<td>
					<div class="Description2">
					<?php foreach($features as $feature){?>
					<strong><?php echo $feature->heading;?></strong><br />
					<p>
					<?php } ?>
					</div>
				</td>
			</tr>
		</tbody></table>
</td></tr>
<tr>
	<td class="underline">
		<table cellspacing="0" cellpadding="0" border="0" class="info">
			<tbody><tr>
				<td valign="top" class="titleTd"><b>Description</b></td></tr><tr>
				<td><div class="Description1"><p><p><?php echo $desc[0]->description;?></div>
				</td>
			</tr>
		</tbody></table>
</td></tr>
<tr>
	<td class="underline">
		<table cellspacing="0" cellpadding="0" border="0" class="info">
			<tbody><tr>
				<td valign="top" id="availability" class="titleTd"><b>Status </b></td>
				<td id="possession">
					<?php switch($pattributes->sold){
					case 0: echo "Available";break;
					case 1: echo "Reduced";break;
					case 2: echo "Sold";break;
					default: break;
					}?>
				</td>
			</tr>
			<tr>
				<td valign="top" class="titleTd"><b>Property Type </b>
				</td>
				<td><?php switch($pattributes->propertyType){
				default: break;
				}?>
				</td>
			</tr>
			<p>
			<tr>
				<td valign="top" class="titleTd"><b>Property Ref  </b>
				</td>
				<td><?php echo $pattributes->id;?>
				</td>
			</tr>
			<p>
			<tr>
				<td valign="top" class="titleTd"><b>Email </b>
				</td>
				<td>
				<?php  echo $branch[0]->email;?>
				</td>
			</tr>
			<tr>
			    <td valign="top" class="titleTd"><b>Telephone </b>
			    </td>
			    <td>
			        <?php  echo $branch[0]->tel;?>
			    </td>
			</tr>
		</tbody></table>
	</td>	
</tr>
</tbody></table>
<p><p><p>
<div class="clearfix"></div>
</div>